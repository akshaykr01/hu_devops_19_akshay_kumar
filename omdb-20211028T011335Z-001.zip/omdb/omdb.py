import requests


val = input("any movie name: ")
response = requests.get('http://www.omdbapi.com/?t={0}&apikey=d5b9c49f'.format(val))
print(response.json())
